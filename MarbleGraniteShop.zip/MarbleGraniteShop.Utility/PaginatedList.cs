﻿using System;
using System.Threading.Tasks;

namespace MarbleGraniteShop.Utility
{
    internal class PaginatedList
    {
        public Task<object> CreateAsync(System.Linq.IQueryable<MarbleGraniteShop.Models.Product> productList, int v, int pageSize)
        {
            throw new NotImplementedException();
        }
    }
}

