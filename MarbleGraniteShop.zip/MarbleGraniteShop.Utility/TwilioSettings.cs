﻿namespace MarbleGraniteShop.Utility
{
    public class TwilioSettings
    {
        public string PhoneNumber { get; set; }
        public string AuthToken { get; set; }
        public string AccountSid { get; set; }
    }
}

