﻿namespace MarbleGraniteShop.DataAccess.Initializer
{
    public interface IDbInitializer
    {
        void Initialize();
    }
}
